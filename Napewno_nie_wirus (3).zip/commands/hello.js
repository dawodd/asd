const Discord = require('discord.js');
const config = require('../config.json');
const os = require('os');

module.exports.run = async (client, message, args) => {
    message.channel.send("Hello "+message.author.tag);
};

module.exports.help = {
    name: "hello"
}