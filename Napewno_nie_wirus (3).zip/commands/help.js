const Discord = require('discord.js');
const config = require('../config.json');
const os = require('os');

module.exports.run = async (client, message, args) => {
    let help = new Discord.MessageEmbed()
    .setTitle(`COMMANDS FOR ${client.user.username}`)
    .setColor('RANDOM')
    .addField("HELLO","Just Hi")
    .setAuthor(client.user.username)
    .setTimestamp()
    message.channel.send(help);
};

module.exports.help = {
    name: "help"
}