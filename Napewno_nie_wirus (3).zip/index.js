const express = require('express')
const app = express();
const port = 3000

app.get('/', (req, res) => res.send('Witaj'))

app.listen(port, () =>
console.log(`Słucham do http://localhost:${port}`)
);
const fs = require('fs');

const Discord = require('discord.js');
const client = new Discord.Client();
const config = require('./config.json');
client.config = config;

fs.readdir("./events/", (_err, files) => {
    files.forEach((file) => {
        if (!file.endsWith(".js")) return;
        const event = require(`./events/${file}`);
        let eventName = file.split(".")[0];
        client.on(eventName, event.bind(null, client));
        delete require.cache[require.resolve(`./events/${file}`)];
    });
});

client.commands = new Discord.Collection();

fs.readdir("./commands/", (_err, files) => {
    files.forEach((file) => {
        if (!file.endsWith(".js")) return;
        let props = require(`./commands/${file}`);
        let commandName = file.split(".")[0];
        client.commands.set(commandName, props);
        console.log(`✅ Command: ${commandName}`);
    });
});
client.on('ready', () => {
 client.user.setActivity(`STATUS :D`, { type: 'PLAYING'})
})
client.login(config.token || process.env.TOKEN).catch((err) => {
  console.log(err.message)
})