module.exports = (client) => {
    console.log(`ZALOGOWANO DO ${client.user.tag}
    https://discord.com/api/oauth2/authorize?client_id=`+client.user.id+`&permissions=8&scope=bot`);
};